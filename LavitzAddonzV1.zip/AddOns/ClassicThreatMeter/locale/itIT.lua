local A, C, L, _ = unpack(select(2, ...))
if GetLocale() ~= "itIT" then return end

-----------------------------
--	itIT client
-----------------------------
-- main frame
L.gui.threat		= "Minaccia"