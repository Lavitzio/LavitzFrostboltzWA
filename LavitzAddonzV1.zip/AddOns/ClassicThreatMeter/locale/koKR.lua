local A, C, L, _ = unpack(select(2, ...))
if GetLocale() ~= "koKR" then return end

-----------------------------
--	koKR client
-----------------------------
-- main frame
L.gui.threat		= "위협"