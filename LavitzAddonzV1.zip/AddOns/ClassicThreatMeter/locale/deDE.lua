local A, C, L, _ = unpack(select(2, ...))
if GetLocale() ~= "deDE" then return end

-----------------------------
--	deDE client
-----------------------------
-- main frame
L.gui.threat		= "Bedrohung"