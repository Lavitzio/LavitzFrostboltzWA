MapCoords
by SDPhantom
http://www.phantomweb.org
===================================================================================================

For questions and bug reports go to the "Contact Me" section of my website and fill out the form.
Use at your own risk, but if anything serious should happen, blame Blizzard's crappy script engine.

Instructions: UnZip the contents into World of Warcraft's "Interface\AddOns" folder.

===================================================================================================
Versions:
	v1.4 (2019-04-11)
		-Fixed 8.0 API changes

	v1.3 (2016-10-29)
		-Fixed Rogue class hall (and possibly other locations) not switching map correctly

	v1.2 (2016-10-26)
		-Fixed 7.1 changes to GetPlayerMapPosition()

	v1.1 (2009-05-08)
		-Optimized hook code

	v1.0 (2007-10-23)
		-Initial version
