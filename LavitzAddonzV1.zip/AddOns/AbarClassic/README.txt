Port of the 1.12.1 addon Attack bar for Classic.
Working player swing timer for BFA and Classic Beta.
Working enemy swing timer (pve and pvp) for BFA and Classic Beta.

Use command /abar

TODO:
- wands, hunter ranged attacks
