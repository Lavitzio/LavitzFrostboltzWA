# HealComm
The luna Healing Communication for the default UI

FOR THE 1.12.1 VERSION SELECT IT FROM THE BRANCH MENU

THIS IS STILL BETA! THERE COULD STILL BE STUFF BROKEN! REPORT BUGS!

paypal.me/LunaUnitFrames

Donations are non-refundable / don't entitle you to anything
