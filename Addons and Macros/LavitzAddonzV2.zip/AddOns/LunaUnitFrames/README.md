# LunaUnitFrames
Unit Frames for WoW Classic

FOR THE 1.12.1 VERSION SELECT IT FROM THE BRANCH MENU

THIS IS STILL BETA! THERE COULD STILL BE STUFF BROKEN! REPORT BUGS!
This is LunaUnitFrames 3.


This Addon supports RealMobHealth.
https://www.wowinterface.com/downloads/info24924-RealMobHealth.html

Clickcasting:
https://www.warcrafttavern.com/addons/clique/

Numeric timers on auras:
https://www.curseforge.com/wow/addons/omni-cc/files?filter-game-version=1738749986%3A67408


This addon comes with LibClassicDurations integrated to view aura durations,

Other features include:

- Config mode for easy setup
- Enemy (and friendly) castbars
- Energy / MP5 ticker
- Druid mana bar
- Reckoning tracker
- Healing communication (green heal bars)
- Totem timer




Feel free to fork this but give credit (at least author & link to this github)

DO NOT REUPLOAD! LINK HERE INSTEAD.


paypal.me/LunaUnitFrames

Donations are non-refundable / don't entitle you to anything
