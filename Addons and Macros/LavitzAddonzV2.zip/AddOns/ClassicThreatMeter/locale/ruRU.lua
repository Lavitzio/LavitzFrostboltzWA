local A, C, L, _ = unpack(select(2, ...))
if GetLocale() ~= "ruRU" then return end

-----------------------------
--	ruRU client
-----------------------------
-- main frame
L.gui.threat		= "Угроза"